package com.example.harkkatyo;

public class White extends Lutemon {

    public White(String name, String color) {
        super(name, color, 5, 4, 0, 20, 20);
        image = R.drawable.white;
    }
}
