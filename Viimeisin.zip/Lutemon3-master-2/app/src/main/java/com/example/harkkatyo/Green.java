package com.example.harkkatyo;


public class Green extends Lutemon {

    public Green(String name, String color) {
            super(name, color, 6, 3, 0, 19, 19);
        image = R.drawable.green;
    }
}

