package com.example.harkkatyo;

public class Pink extends Lutemon {

    public Pink(String name, String color) {
        super(name, color, 7, 2, 0, 18, 18);
        image = R.drawable.pink;
    }
}
